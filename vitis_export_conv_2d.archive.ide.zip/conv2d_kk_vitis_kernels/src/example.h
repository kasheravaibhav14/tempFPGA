void example(volatile int *a, int *w);
