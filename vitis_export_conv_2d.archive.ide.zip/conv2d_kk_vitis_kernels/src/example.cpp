/*
 * Copyright 2021 Xilinx, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * This file contains an example for creating an AXI4-master interface in Vivado HLS
 */
				      
#include <stdio.h>
#include <string.h>

void conv2d(int buff[104][104], int w1[3][3],int buff2[102][102]){
	 LoopConvolution:
	    for(int i=1;i<102;i++){
	#pragma HLS PIPELINE II=1
	    	for(int j=1;j<102;j++){
	    		buff2[i][j]=0;
	    		for(int k=-1;k<2;k++){
	    			for(int l=-1;l<2;l++){
	    				buff2[i][j]+= buff[i+k][j+l]*w1[k+1][l+1];
//	    			printf("%d\t%d\t%d\t%d\t%d\t%d\n",i,j,i+k,j+l,k+1,l+1);

	    			}
	    		}
//	    		printf("......\n");
	    	}
	    }
	    printf("........conv2d in Kernel completed..........");
}

template<int inW,int inH>
void Relu(int buff[inW][inH], int buff2[inW][inH]){
	buff2[inW][inH]=(buff[inW][inH]>=0)? buff[inW][inH]:-buff[inW][inH];
}
template<int inW,int inH>
void Bn(int buff[inW][inH], int bias, int coeff)
{
	for(int i=0;i<inW;i++)
		for(int j=0;j<inH;j++){
			buff[i][j] = buff[i][j]*coeff + bias;
		}
}


extern "C"{
void example(volatile int *a, int *w){
  
#pragma HLS INTERFACE m_axi port=a depth=100

#pragma HLS INTERFACE m_axi offset = slave bundle = gmem1 port = a latency = 64 \
  num_read_outstanding = 16 num_write_outstanding = 16 \
  max_read_burst_length = 64 max_write_burst_length = 64 depth=64

#pragma HLS INTERFACE m_axi offset = slave bundle = gmem2 port = w latency = 64 \
  num_read_outstanding = 16 num_write_outstanding = 16 \
  max_read_burst_length = 64 max_write_burst_length = 64 depth=64

#pragma HLS INTERFACE s_axilite port = a bundle = control
#pragma HLS INTERFACE s_axilite port = w bundle = control

#pragma HLS INTERFACE s_axilite port = return bundle = control

  int i;
  int buff[104][104];
  int buff2[4][102][102];
  int w1[8][4][3][3];
//   int w1[3][3];

  int buff1[102][102];
#pragma HLS array_partition variable = buff complete
#pragma HLS resource variable = buff core = XPM_MEMORY bram
  //memcpy creates a burst access to memory
  //multiple calls of memcpy cannot be pipelined and will be scheduled sequentially
  //memcpy requires a local buffer to store the results of the memory transaction
  printf(".... in example .....\n");
  Loop0:
  for(i=0; i < 104; i++){
	  for(int j=0; j<104;j++)
		  if(i ==0 ||j==0 ||i==103 ||j==103)
			  buff[i][j] = 0;
		  else
			  buff[i][j] = a[102*i+j];
    }
  for(int l=0;l<8;l++){
  for(int k=0;k<4;k++){
  for(int i=0; i < 3; i++){
  	  for(int j=0; j<3;j++)
  		  //w1[l][k][i][j] = w[8*l+4*k+3*i+j];
  	w1[l][k][i][j] = w[3*i+j];
      }
  }
  }

 // memcpy(buff,(const int*)a,100*sizeof(int));
#pragma HLS DATAFLOW

  conv2d(buff,w1[0][0],buff2[0]);
  conv2d(buff,w1[0][1],buff2[1]);
  conv2d(buff,w1[0][2],buff2[2]);
   conv2d(buff,w1[0][3],buff2[3]);

//  LoopConvolution:
//    for(int i=1;i<103;i++){
//#pragma HLS PIPELINE II=1
//    	for(int j=1;j<103;j++){
//    		buff2[i][j]=0;
//    		for(int k=-1;k<2;k++){
//    			for(int l=-1;l<2;l++){
//    				buff2[i][j]+= buff[i+k][j+l]*w1[k+1][l+1];
//    				printf("%d\t%d\t%d\t%d\t%d\t%d\n",i,j,i+k,j+l,k+1,l+1);
//
//    			}
//    		}
//    		//printf("......\n");
//    	}
//    }

//  Loop2:
//  for(i=0; i < 5; i++){
//  	  for(int j=0; j<5;j++)
//        buff1[i][j] = a[10*i+j]+100;
//      }
//  Loop3:
//  for(i=0; i < 256; i++){
//    	  for(int j=0; j<256;j++){
//          a[256*i+j] = buff[i][j]+100;
//        }
//    }
  //memcpy((int *)a,buff,100*sizeof(int));
}
}

  

