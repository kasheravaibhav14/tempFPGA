/*
 * Copyright 2019 Xilinx, Inc.

 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
//namespace internal {

// update submatrix


//}; // end of namespace internal



// Actual Kernel


#include "xf_solver_L2.hpp"
#include <iostream.h>

#define NRC 16
#define NCU 1


extern "C" {




void kernel_getrf_nopivot_0(double* A) {
//	std::cout<<"kernel_test_print"<<A[0];
// clang-format off

	std::cout<<std::endl<<std::endl<<"-------------------------------------"
			"A inside Kernel1-----------------------------------"<<std::endl<<std::endl;
	for(int i=0;i<NRC;i++){
		for(int j=0;j<NRC;j++){
			std::cout<<A[NRC*i+j]<<" ";
		}
		std::cout<<std::endl;
	}

#pragma HLS INTERFACE m_axi offset = slave bundle = gmem0 port = A latency = 64 num_read_outstanding = 16 \
    num_write_outstanding = 16 max_read_burst_length = 64 max_write_burst_length = 64 depth = 16*16

// clang-format on
#pragma HLS INTERFACE s_axilite port = A bundle = control
//#pragma HLS INTERFACE s_axilite port = NCU bundle = control
//#pragma HLS INTERFACE s_axilite port = NRC bundle = control
#pragma HLS INTERFACE s_axilite port = return bundle = control

    int info;
    //xf::solver::getrf_nopivot<double, NRC, NCU>(NRC, A, NRC, info);
    getrf_nopivot<double, NRC, NCU>(NRC, A, NRC, info);

};
};
